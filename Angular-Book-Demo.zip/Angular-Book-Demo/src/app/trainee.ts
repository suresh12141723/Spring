export class Trainee {
  traineeId:number;
  traineeName:string;
  traineeDomain:string;
  traineeLocation:string;
}
